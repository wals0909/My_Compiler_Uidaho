#ifndef SCANTYPE_H
#define SCANTYPE_H

struct TokenData {
    int mytoken;      // token class
    char *tokenStrprint; 
    int idIndex;
    int linenum;         // what line did this token occur on?
    char *tokenstr;    
    char charvalue;         
    int numvalue;          
    char *stringvalue;       
    int strlength;
};

#endif
